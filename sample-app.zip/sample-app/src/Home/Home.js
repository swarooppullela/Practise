import React from 'react';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = { txtbox1: "", txtbox2: "", txtbox3: "" };
    this.onSubmiClick = this.onSubmiClick.bind(this);
  }
  onSubmiClick = () => {
    this.props.history.push('/OtpPage');
  }
 
  render() {
    return (
      <div id="welcome-block">
        <form>
          <p>Please enter some Text</p>
          <input type="text" placeholder="Enter text here" required onChange={event => this.setState({ txtbox1: event.target.value })} value={this.state.txtbox1} /><br />
          <p>Please enter some Text</p>
          <input type="text" placeholder="Enter text here" required onChange={event => this.setState({ txtbox2: event.target.value })} value={this.state.txtbox2} /><br />
          <p>Please enter numbers</p>
          <input type="number" placeholder="Enter numbers here" required onChange={event => this.setState({ txtbox3: event.target.value })} value={this.state.txtbox3} /><br />
          {this.state.txtbox1 && this.state.txtbox1 !== "" && this.state.txtbox2 && this.state.txtbox2 !== "" && this.state.txtbox3 && this.state.txtbox3 !== "" ?
            <input type="submit" value="Submit"  onClick={this.onSubmiClick}/>
            : ""}
        </form>
      </div>
    );
  }
  

 
}

export default Home;
