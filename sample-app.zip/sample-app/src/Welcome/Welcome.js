import React from 'react';
import '../App.css';

class Welcome extends React.Component {
  render() {
    return (
      <div id="Success-block">
        <h1>Success!!!</h1>
      </div>
    );
  }

}

export default Welcome;
