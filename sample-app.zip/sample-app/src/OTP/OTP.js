import React from 'react';
import '../App.css';

class OTP extends React.Component {
  constructor(props) {
    super(props);
    this.state = { otp: "", success: false };
    this.onSubmiClick = this.onSubmiClick.bind(this);
  }
  onSubmiClick = () => {
    +this.state.otp === 12345 ?  this.props.history.push('/Welcome') : this.props.history.push('/OtpPage');
  }
  render() {
    return (
      <div id="OTP-block">
        <form>
          <input type="number" placeholder="Enter OTP 12345" required onChange={event => this.setState({ otp: event.target.value })} value={this.state.otp} /><br />
          <input type="submit" value="Submit" onClick={this.onSubmiClick} />
        </form>
      </div>
    );
  }

}

export default OTP;
